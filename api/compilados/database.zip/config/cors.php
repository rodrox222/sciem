<?php

return [
    'paths' => ['api/*', 'sanctum/csrf-cookie'],

    'allowed_methods' => ['*'],

    'allowed_origins' => [
        'https://sciem-five.vercel.app',
        'http://localhost:5173',
        'http://localhost:4173',
        'http://localhost',
        'https://localhost',
        'capacitor://localhost',
        'http://127.0.0.1:8200',
        'http://sso.tis.cs.umss.edu.bo',
        
    ],

    'allowed_origins_patterns' => [],

    'allowed_headers' => ['*'],

    'exposed_headers' => [],

    'max_age' => 86400,

    'supports_credentials' => true,
];
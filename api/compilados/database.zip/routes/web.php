<?php

use Illuminate\Support\Facades\Route;

// Ruta raíz: sirve el frontend compilado si existe public/index.html, o el Health Check de la API
Route::get('/', function () {
    $indexHtml = public_path('index.html');
    if (is_file($indexHtml)) {
        return response(file_get_contents($indexHtml), 200)
            ->header('Content-Type', 'text/html; charset=UTF-8');
    }

    return response()->json([
        'status'  => 'online',
        'service' => 'SCIEM Backend API',
    ]);
});

// Rutas auxiliares de prueba para vistas Blade
Route::get('/test-login', function () {
    return view('test_auth');
});

Route::get('/reset-password', function () {
    return view('test-reset');
});


Route::fallback(function () {
    if (request()->is('api/*')) {
        return response()->json(['message' => 'Ruta de API no encontrada.'], 404);
    }

    $indexHtml = public_path('index.html');
    if (is_file($indexHtml)) {
        return response(file_get_contents($indexHtml), 200)
            ->header('Content-Type', 'text/html; charset=UTF-8');
    }

    abort(404);
});
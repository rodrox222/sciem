<?php

namespace App\Http\Controllers;

use App\Models\Auxiliar;
use App\Models\Docente;
use App\Models\LogAuditoria;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class ForgotPasswordController extends Controller
{
    public function sendResetLink(Request $request): JsonResponse
    {
        $request->validate([
            'email' => [
                'required',
                'string',
                'email',
                'regex:/^[a-zA-Z0-9._%+-]+@(fcyt\.umss\.edu\.bo|est\.umss\.edu|gmail\.com)$/i',
            ],
        ], [
            'email.regex' => 'El correo electrónico ingresado no es un correo permitido.',
        ]);

        $cuenta = $this->buscarPorEmail($request->email);

        if (!$cuenta) {
            return response()->json([
                'message' => 'Si el correo electrónico existe en el sistema, recibirá un enlace de recuperación.'
            ], 200);
        }

        $user = $cuenta['user'];
        $tipo = $cuenta['tipo'];

        $plainToken = Str::random(64);

        DB::table('password_reset_tokens')->updateOrInsert(
            ['email' => $user->email],
            [
                'token'      => Hash::make($plainToken),
                'created_at' => Carbon::now(),
            ]
        );

        $frontendUrl = env('FRONTEND_URL', 'http://localhost:4173');
        $resetUrl = "{$frontendUrl}/recuperar-contrasena?token={$plainToken}&email=" . urlencode($user->email);

        Mail::send('emails.reset-password', ['user' => $user, 'resetUrl' => $resetUrl], function ($message) use ($user) {
            $message->to($user->email)
                    ->subject('Restablecimiento de Contraseña - SCI');
        });

        $nombreCompleto = trim("{$user->nombre} {$user->apellido_paterno} " . ($user->apellido_materno ?? ''));

        LogAuditoria::create([
            'user_type'         => get_class($user),
            'user_id'           => $user->id,
            'rol_en_el_momento' => $tipo,
            'usuario_nombre'    => $nombreCompleto,
            'usuario_email'     => $user->email,
            'modulo'            => 'Autenticacion',
            'accion'            => 'PASSWORD_RESET_SOLICITADO',
            'ip_origen'         => $request->ip() ?? '127.0.0.1',
            'user_agent'        => $request->userAgent(),
            'detalles'          => [
                'email' => $user->email,
                'rol'   => $tipo,
            ],
        ]);

        return response()->json([
            'message' => 'Si el correo electrónico existe en el sistema, recibirá un enlace de recuperación.'
        ], 200);
    }

    public function resetPassword(Request $request): JsonResponse
    {
        $request->validate([
            'token'    => 'required|string',
            'email'    => 'required|email',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $cuenta = $this->buscarPorEmail($request->email);
        $errorResponse = $this->validateResetRequest($request, $cuenta);

        if ($errorResponse) {
            return $errorResponse;
        }

        $user = $cuenta['user'];
        $tipo = $cuenta['tipo'];

        $user->forceFill([
            'password' => Hash::make($request->password),
        ])->save();

        $user->tokens()->delete();

        DB::table('password_reset_tokens')->where('email', $request->email)->delete();

        $nombreCompleto = trim("{$user->nombre} {$user->apellido_paterno} " . ($user->apellido_materno ?? ''));

        LogAuditoria::create([
            'user_type'         => get_class($user),
            'user_id'           => $user->id,
            'rol_en_el_momento' => $tipo,
            'usuario_nombre'    => $nombreCompleto,
            'usuario_email'     => $user->email,
            'modulo'            => 'Autenticacion',
            'accion'            => 'PASSWORD_RESET_EXITOSO',
            'ip_origen'         => $request->ip() ?? '127.0.0.1',
            'user_agent'        => $request->userAgent(),
            'detalles'          => [
                'target_type' => strtolower($tipo),
                'target_id'   => $user->id,
                'rol'         => $tipo,
                'mensaje'     => 'Contraseña actualizada y sesiones previas revocadas',
            ],
        ]);

        return response()->json([
            'message' => 'Tu contraseña ha sido restablecida exitosamente. Ya puedes iniciar sesión con tu nueva contraseña.'
        ], 200);
    }

    private function validateResetRequest(Request $request, ?array $cuenta): ?JsonResponse
    {
        $errorResponse = null;
        $record = DB::table('password_reset_tokens')->where('email', $request->email)->first();

        if (!$record) {
            $errorResponse = response()->json(['message' => 'El enlace de recuperación es inválido o ya ha sido utilizado.'], 400);
        } elseif (Carbon::parse($record->created_at)->addMinutes(60)->isPast()) {
            DB::table('password_reset_tokens')->where('email', $request->email)->delete();
            $errorResponse = response()->json(['message' => 'El enlace de recuperación ha expirado. Solicite uno nuevo.'], 400);
        } elseif (!Hash::check($request->token, $record->token)) {
            $errorResponse = response()->json(['message' => 'El token proporcionado no es válido.'], 400);
        } elseif (!$cuenta) {
            $errorResponse = response()->json(['message' => 'Usuario no encontrado.'], 404);
        }

        return $errorResponse;
    }

    private function buscarPorEmail(string $email): ?array
    {
        if ($docente = Docente::where('email', $email)->first()) {
            return ['user' => $docente, 'tipo' => 'docente'];
        }

        if ($auxiliar = Auxiliar::where('email', $email)->first()) {
            return ['user' => $auxiliar, 'tipo' => 'auxiliar'];
        }

        return null;
    }
}
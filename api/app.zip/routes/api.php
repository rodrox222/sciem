<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Cache;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ForgotPasswordController;
use App\Http\Controllers\GestionController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AuditoriaController;
use App\Http\Controllers\AulaController;
use App\Http\Controllers\ExamenController;
use App\Http\Controllers\MateriaController;
use App\Http\Controllers\NormaController;
use App\Http\Controllers\EstudianteController;
use App\Http\Controllers\HabilitacionExamenController;
use App\Http\Controllers\PrerrequisitoController;
use App\Http\Controllers\VerificacionController;
use App\Http\Controllers\CargaMasivaEstudianteController;
use App\Http\Controllers\ConfiguracionSistemaController;
use App\Http\Controllers\IntentoNoAutorizadoController;
use App\Http\Controllers\AuxiliarModuloController;
use App\Http\Controllers\ExpulsionController;
use App\Http\Controllers\MonitoreoController;
use App\Http\Controllers\ReporteEstadisticoController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\AuxiliarOfflineController;
use App\Models\Admin;
use App\Models\Docente;
use App\Models\Auxiliar;
use App\Http\Controllers\NoticiaController;

// --- RUTAS PÚBLICAS ---
Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:5,1');
Route::post('/forgot-password', [ForgotPasswordController::class, 'sendResetLink']);
Route::post('/reset-password', [ForgotPasswordController::class, 'resetPassword']);
Route::get('noticias', [NoticiaController::class, 'index']);
Route::get('gestiones', [GestionController::class, 'index']);
Route::get('gestiones/activa', [GestionController::class, 'activa']);

// Comprobación ligera de conectividad para el temporizador de sesión.
Route::get('health', fn () => response()->noContent());

Route::get('examenes', [ExamenController::class, 'index']);

Route::pattern('idExamen', '[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}');
Route::pattern('expulsionId', '[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}');

// --- RUTAS PROTEGIDAS (Sanctum) ---
Route::middleware('auth:sanctum')->group(function () {
    Route::get('dashboard', [DashboardController::class, 'index'])->middleware(\App\Http\Middleware\InstantaneaLectura::class);
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('configuracion/inactividad', [ConfiguracionSistemaController::class, 'getTiempoInactividad']);

    // Perfil del usuario autenticado
    Route::get('/me', function (Request $request) {
        $user = $request->user();

        $rol = \App\Services\RolOperativo::actual($request);
        abort_unless($rol, 403, 'Sesión inactiva o ambigua; vuelva a iniciar sesión.');

        return response()->json([
            'id'                       => $user->id,
            'ci'                       => $user->ci,
            'ci_extension'             => $user->ci_extension,
            'nombre'                   => $user->nombre,
            'apellido_paterno'         => $user->apellido_paterno,
            'apellido_materno'         => $user->apellido_materno,
            'email'                    => $user->email ?? $user->email_institucional ?? null,
            'codigo_sis'               => $user->codigo_sis ?? null,
            'foto_perfil_url'          => $user->foto_perfil_url ?? null,
            'primer_acceso_completado' => $user->primer_acceso_completado ?? null,
            'es_auxiliar'              => $user->es_auxiliar ?? null,
            'rol'                      => $rol,
            'activo'                   => $user->activo,
            'ultimo_acceso'            => $user->ultimo_acceso,
        ]);
    });

    // Endpoint de roles para selectores de Usuarios (excluye Admin, gestionado en Configuración)
    Route::get('roles', function () {
        return response()->json([
            ['id' => 'docente', 'nombre' => 'Docente', 'disponible' => true],
            ['id' => 'auxiliar', 'nombre' => 'Auxiliar', 'disponible' => true],
        ]);
    });

    // Catálogo directo y compatible con PostgreSQL nativo
    Route::middleware('role:admin,administrador,docente')->get('docentes', function () {
        $docentes = Cache::remember('catalogo_docentes_activos', 600, function () {
            return \Illuminate\Support\Facades\DB::table('docente')
                ->whereRaw('activo is true')
                ->orderBy('nombre', 'asc')
                ->select(['id', 'nombre', 'apellido_paterno', 'apellido_materno'])
                ->get();
        });

        return response()->json($docentes);
    });

    // --- ADMINISTRACIÓN Y AUDITORÍA ---
    Route::middleware('role:admin,administrador')->group(function () {
        Route::get('dashboard/stats', function () {
            $totalUsuarios = \App\Models\Admin::count() 
                           + \App\Models\Docente::count() 
                           + \App\Models\Auxiliar::count();

            $totalAulasDisponibles = \App\Models\Aula::where('estado', 'Disponible')->count();
            $totalExamenesActivos  = \App\Models\Examen::where('estado', 'Programado')->count();
            $totalEstudiantes      = \App\Models\Estudiante::count();

            return response()->json([
                'users'    => $totalUsuarios,
                'rooms'    => $totalAulasDisponibles,
                'exams'    => $totalExamenesActivos,
                'students' => $totalEstudiantes,
            ]);
        });

        Route::apiResource('users', UserController::class);
        Route::get('users/{id}/materias', [UserController::class, 'getMateriasDocente']);
        Route::post('users/{id}/materias', [UserController::class, 'syncMateriasDocente']);
        Route::post('users/{id}/materias/{idMateria}', [UserController::class, 'vincularMateriaDocente']);
        Route::delete('users/{id}/materias/{idMateria}', [UserController::class, 'desvincularMateriaDocente']);

        // Módulo de Auditoría y Reversión Compensatoria
        Route::get('auditoria', [AuditoriaController::class, 'index']);
        Route::post('auditoria/{id}/revertir', [AuditoriaController::class, 'revertir']);

        // Parámetro de inactividad de sesión (solo admin modifica)
        Route::put('configuracion/inactividad', [ConfiguracionSistemaController::class, 'updateTiempoInactividad']);
        Route::put('admin/perfil', [ConfiguracionSistemaController::class, 'updatePerfilAdmin']);

        // Gestión / Semestres académicos
        Route::post('gestiones', [GestionController::class, 'store']);
        Route::put('gestiones/{id}', [GestionController::class, 'update']);
        Route::post('gestiones/{id}/cerrar', [GestionController::class, 'cerrar']);
    });

    // --- PERFIL DOCENTE (autoasignación de materias) ---
    Route::middleware('role:docente')->group(function () {
        Route::get('docente/materias', [UserController::class, 'getMisMateriasDocente']);
        Route::post('docente/materias', [UserController::class, 'syncMisMateriasDocente']);
    });

    // --- AULAS / AMBIENTES ---
    Route::middleware('role:admin,administrador,docente,auxiliar')->group(function () {
        Route::get('aulas', [AulaController::class, 'index']);
        Route::get('aulas/{id}', [AulaController::class, 'show']);
        Route::get('ambientes', [AulaController::class, 'index']);
        Route::get('ambientes/{id}', [AulaController::class, 'show']);
    });

    Route::middleware('role:admin,administrador,docente')->group(function () {
        Route::post('aulas', [AulaController::class, 'store']);
        Route::put('aulas/{id}', [AulaController::class, 'update']);
        Route::delete('aulas/{id}', [AulaController::class, 'destroy']);
        Route::post('ambientes', [AulaController::class, 'store']);
        Route::put('ambientes/{id}', [AulaController::class, 'update']);
        Route::delete('ambientes/{id}', [AulaController::class, 'destroy']);
    });

    // --- EXÁMENES ---
    Route::middleware('role:admin,administrador,docente')->group(function () {
        Route::post('examenes', [ExamenController::class, 'store']);
        Route::put('examenes/{id}', [ExamenController::class, 'update']);
        Route::delete('examenes/{id}', [ExamenController::class, 'destroy']);
    });

    Route::middleware('role:admin,administrador,docente,auxiliar')->group(function () {
        Route::get('mis-examenes', [ExamenController::class, 'misExamenes']);
        Route::get('examenes/{id}', [ExamenController::class, 'show']);
    });

    // --- MATERIAS ---
    Route::middleware('role:admin,administrador,docente,auxiliar')->group(function () {
        Route::get('materias', [MateriaController::class, 'index']);
        Route::get('materias/{id}', [MateriaController::class, 'show']);
    });

    Route::middleware('role:admin,administrador,docente')->group(function () {
        Route::post('materias', [MateriaController::class, 'store']);
        Route::put('materias/{id}', [MateriaController::class, 'update']);
        Route::delete('materias/{id}', [MateriaController::class, 'destroy']);
    });

    // --- NORMAS ---
    Route::middleware('role:admin,administrador')->post('normas', [NormaController::class, 'store']);
    Route::middleware('role:admin,administrador,docente,auxiliar')->group(function () {
        Route::get('normas', [NormaController::class, 'index']);
        Route::get('normas/{id}', [NormaController::class, 'show']);
    });

    Route::middleware('role:admin,administrador,docente')->group(function () {
        Route::put('normas/{id}', [NormaController::class, 'update']);
        Route::delete('normas/{id}', [NormaController::class, 'destroy']);
        Route::patch('normas/{id}/reactivar', [NormaController::class, 'reactivar']);
        Route::delete('normas/{id}/force', [NormaController::class, 'forceDelete']);
        Route::post('examenes/{id}/normas', [NormaController::class, 'syncExamenNormas']);
        Route::post('examenes/{id}/normas/particulares', [NormaController::class, 'crearParticularesParaExamen']);
    });

    // --- ESTUDIANTES (Padrón general) ---
    Route::middleware('role:admin,administrador,docente,auxiliar')->group(function () {
        Route::get('estudiantes', [EstudianteController::class, 'index']);
        Route::get('estudiantes/buscar', [EstudianteController::class, 'buscar']);
        Route::get('estudiantes/{identificador}', [EstudianteController::class, 'show']);
        Route::middleware('role:admin,administrador,docente')->group(function () {
            Route::patch('estudiantes/{id}/toggle-auxiliar', [EstudianteController::class, 'toggleAuxiliar']);
        });
    });

    // --- INSCRIPCIÓN Y GESTIÓN EN EXAMEN ---
    Route::middleware('role:admin,administrador,docente')->group(function () {
        Route::post('examenes/{id}/estudiantes', [EstudianteController::class, 'inscribirAExamen']);
        Route::put('examenes/{id}/estudiantes/{idEstudiante}', [EstudianteController::class, 'actualizarEnExamen']);
        Route::delete('examenes/{id}/estudiantes/{idEstudiante}', [EstudianteController::class, 'desvincularDeExamen']);
        Route::post('examenes/{idExamen}/estudiantes/carga-masiva', [CargaMasivaEstudianteController::class, 'storePorExamen']);
    });

    // --- HU 9: PRERREQUISITOS Y HABILITACIÓN ---
    Route::middleware('role:admin,administrador,docente,auxiliar')->group(function () {
        Route::get('examenes/{examen}/estudiantes', [HabilitacionExamenController::class, 'index']);
        Route::get('examenes/{examen}/estudiantes/{estudiante}/motivo', [HabilitacionExamenController::class, 'motivoInhabilitacion']);
    });

    Route::middleware('role:admin,administrador,docente,auxiliar,estudiante')->group(function () {
        Route::get('examenes/{examen}/prerrequisitos', [PrerrequisitoController::class, 'index']);
    });

    Route::middleware('role:admin,administrador,docente')->group(function () {
        Route::post('examenes/{examen}/prerrequisitos', [PrerrequisitoController::class, 'store']);
        Route::patch('prerrequisitos/{prerrequisito}/estudiantes/{estudiante}', [PrerrequisitoController::class, 'toggleCumplimiento']);
        Route::patch('examenes/{examen}/estudiantes/{estudiante}/habilitacion', [HabilitacionExamenController::class, 'update']);
        Route::get('examenes/{examen}/estudiantes/{estudiante}/prerrequisitos', [PrerrequisitoController::class, 'prerrequisitosPorEstudiante']);
    });

    // --- HU 10: ESCANEO QR Y CONTROL DE ACCESO ---
    Route::middleware('role:admin,administrador,docente,auxiliar')->group(function () {
        Route::post('examenes/{id}/verificar-ingreso', [VerificacionController::class, 'verificarIngreso']);
        Route::post('/examenes/{id}/registro-manual', [VerificacionController::class, 'registrarIngresoManual']);
    });

    // --- HU 15: REGISTRO Y CONSULTA DE EXPULSIONES ---
    Route::middleware('role:admin,administrador,docente,auxiliar')->group(function () {
        Route::get('examenes/{id}/expulsiones', [ExpulsionController::class, 'index']);
        Route::get('examenes/{id}/expulsiones/estudiantes', [ExpulsionController::class, 'estudiantes']);
        Route::delete('examenes/{id}/expulsiones/{expulsionId}', [ExpulsionController::class, 'destroy']);
        Route::post('examenes/{id}/expulsiones', [ExpulsionController::class, 'store']);
        Route::patch('examenes/{id}/expulsiones/{expulsionId}', [ExpulsionController::class, 'updateMotivo']);
    });

    Route::middleware('role:admin,administrador,docente')->group(function () {
        Route::get('/examenes/{id}/asistencias', [VerificacionController::class, 'listarAsistencias']);
    });

    // HU 13: REGISTRO Y CONSULTA DE INTENTOS NO CORRESPONDIENTES 
    Route::middleware('role:admin,administrador,docente,auxiliar')->group(function () {
        Route::get('examenes/{id_examen}/intentos-no-autorizados', [IntentoNoAutorizadoController::class, 'index']);
        Route::post('examenes/{id_examen}/escanear-ingreso', [VerificacionController::class, 'verificarIngreso']);
    });

    // MONITOREO EN TIEMPO REAL (HU16) 
    Route::middleware('role:admin,administrador,docente')->group(function () {
        Route::get('examenes/{idExamen}/monitoreo', [MonitoreoController::class, 'resumen']);
        Route::get('examenes/{idExamen}/monitoreo/estudiantes', [MonitoreoController::class, 'estudiantes']);
    });

    // HU 17: REPORTES ESTADÍSTICOS
    Route::middleware('role:admin,administrador,docente')->group(function () {
        Route::get('examenes/{idExamen}/reportes/estadisticas', [ReporteEstadisticoController::class, 'resumen']);
        Route::get('examenes/{idExamen}/reportes/estadisticas/franjas-horarias', [ReporteEstadisticoController::class, 'franjasHorarias']);
        Route::get('examenes/{idExamen}/reportes/estadisticas/descargar', [ReporteEstadisticoController::class, 'descargar']);
        Route::get('examenes/{idExamen}/reportes/acta-disciplinaria/descargar', [ReporteEstadisticoController::class, 'descargarActaDisciplinaria']);
        Route::get('examenes/{idExamen}/reportes/auditoria-puerta/descargar', [ReporteEstadisticoController::class, 'descargarAuditoriaPuerta']);
        Route::get('examenes/{idExamen}/reportes/matriz-habilitacion-asistencia/descargar', [ReporteEstadisticoController::class, 'descargarMatrizHabilitacionAsistencia']);
        Route::get('examenes/{idExamen}/reportes/estadisticas/graficos', [ReporteEstadisticoController::class, 'graficosEstadisticos']);
    });

    // HU 18: MODULO DE ESTUDIANTES
    Route::middleware('role:estudiante')->prefix('estudiante')->group(function () {
        Route::match(['post', 'patch'], '/completar-datos', [EstudianteController::class, 'completarDatos']);
        Route::post('/foto', [EstudianteController::class, 'subirFoto']);
        Route::get('/mis-examenes', [EstudianteController::class, 'misExamenes']);
        Route::post('/examenes/{idExamen}/qr-token', [EstudianteController::class, 'generarTokenQr']);
        Route::put('/cambiar-password', [EstudianteController::class, 'cambiarPassword']);
    });

    // HU 19: GESTIÓN DE AUXILIARES
    Route::middleware('role:auxiliar')->prefix('auxiliar')->group(function () {
        Route::get('/mis-examenes', [AuxiliarModuloController::class, 'misExamenesAsignados']);
    });

    Route::middleware('role:admin,administrador,docente')->group(function () {
        Route::post('examenes/{id_examen}/auxiliares', [AuxiliarModuloController::class, 'invitarAuxiliar']);
        Route::get('examenes/{id_examen}/auxiliares', [AuxiliarModuloController::class, 'listarAuxiliaresExamen']);
        Route::get('examenes/{id_examen}/auxiliares-disponibles', [AuxiliarModuloController::class, 'auxiliaresDisponibles']);
        Route::delete('examenes/{id_examen}/auxiliares/{id_auxiliar}', [AuxiliarModuloController::class, 'desvincularAuxiliar']);
    });

    Route::middleware('role:admin,administrador,docente,auxiliar,estudiante')->group(function () {
        Route::get('estudiante/foto/{idEstudiante}', [EstudianteController::class, 'verFoto']);
    });

    // MODO OFFLINE
    Route::middleware('role:admin,administrador,docente,auxiliar')->group(function () {
        Route::get('/examenes/{id}/descargar-padron', [AuxiliarOfflineController::class, 'descargarPadron']);
        Route::post('/examenes/{id}/sincronizar-asistencias', [AuxiliarOfflineController::class, 'sincronizarAsistencias']);
    });

    // --- HU 14: NOTICIAS OPERATIVAS ---
    Route::middleware('role:admin,administrador,docente,auxiliar,estudiante')->group(function () {
        Route::get('noticias/internas', [NoticiaController::class, 'index']); 
    });

    Route::middleware('role:admin,administrador,docente')->group(function () {
        Route::post('noticias', [NoticiaController::class, 'store']);
        Route::put('noticias/{id}', [NoticiaController::class, 'update']);
        Route::delete('noticias/{id}', [NoticiaController::class, 'destroy']);
    });
});

// Middleware dinámicos por patrón de rutas
foreach (Route::getRoutes() as $route) {
    if (in_array('POST', $route->methods()) || in_array('PATCH', $route->methods()) || in_array('DELETE', $route->methods())) {
        if (preg_match('~^api/examenes/\{id\}/(verificar-ingreso|registro-manual|sincronizar-asistencias|expulsiones)(/.*)?$~', $route->uri())) {
            $route->middleware(\App\Http\Middleware\OperacionExamen::class);
        }
    }
    if ($route->uri() === 'api/examenes/{id_examen}/escanear-ingreso') $route->middleware(\App\Http\Middleware\OperacionExamen::class);
    if (str_contains($route->uri(), '/monitoreo') || str_contains($route->uri(), '/reportes/estadisticas')) {
        $route->middleware(\App\Http\Middleware\InstantaneaLectura::class);
    }
}
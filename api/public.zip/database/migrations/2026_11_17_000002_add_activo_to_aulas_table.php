<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasColumn('aulas', 'activo')) {
            Schema::table('aulas', function (Blueprint $table) {
                $table->boolean('activo')->default(true);
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('aulas', 'activo')) {
            Schema::table('aulas', function (Blueprint $table) {
                $table->dropColumn('activo');
            });
        }
    }
};

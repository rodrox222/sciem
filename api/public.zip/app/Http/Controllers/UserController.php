<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Models\Admin;
use App\Models\Auxiliar;
use App\Models\Docente;
use App\Models\Examen;
use App\Models\LogAuditoria;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class UserController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $tipo = $request->query('tipo_usuario');
        $search = $request->query('search');
        $activo = $request->filled('activo') ? filter_var($request->query('activo'), FILTER_VALIDATE_BOOLEAN) : null;

        $coleccion = collect();

        if (!$tipo || $tipo === 'docente') {
            $query = Docente::query()->with('materias:id,nombre');
            $this->aplicarFiltros($query, $search, $activo, true);
            $coleccion = $coleccion->concat($query->get()->map(fn ($u) => $this->formatearUsuario($u, 'docente')));
        }

        if (!$tipo || $tipo === 'auxiliar') {
            $query = Auxiliar::query();
            $this->aplicarFiltros($query, $search, $activo, true);
            $coleccion = $coleccion->concat($query->get()->map(fn ($u) => $this->formatearUsuario($u, 'auxiliar')));
        }

        $coleccion = $coleccion->sortByDesc('created_at')->values();

        $page = LengthAwarePaginator::resolveCurrentPage();
        $perPage = (int) $request->query('per_page', 10);
        $items = $coleccion->slice(($page - 1) * $perPage, $perPage)->values();
        $paginado = new LengthAwarePaginator($items, $coleccion->count(), $perPage, $page, [
            'path'  => LengthAwarePaginator::resolveCurrentPath(),
            'query' => $request->query(),
        ]);

        return response()->json($paginado);
    }

    public function store(StoreUserRequest $request): JsonResponse
    {
        $data = $request->validated();
        $tipo = $data['tipo_usuario'];

        if ($tipo === 'admin' && Admin::count() > 0) {
            return response()->json([
                'message' => 'Ya existe un administrador registrado en el sistema. No se permite crear más de un administrador.',
                'errors'  => [
                    'tipo_usuario' => ['Ya existe un administrador registrado en el sistema. No se permite crear más de un administrador.'],
                ],
            ], 422);
        }

        unset($data['tipo_usuario']);

        $activoBool = isset($data['activo'])
            ? filter_var($data['activo'], FILTER_VALIDATE_BOOLEAN)
            : true;

        if ($tipo === 'admin') {
            unset($data['email']);
        }

        $data['activo'] = $activoBool ? DB::raw('true') : DB::raw('false');

        $modelClass = $this->obtenerClaseModelo($tipo);
        $user = new $modelClass();
        $user->fill($data);
        $user->save();

        if ($tipo === 'docente' && $request->has('materias_ids') && is_array($request->input('materias_ids'))) {
            $user->materias()->sync($request->input('materias_ids'));
        }

        try {
            $this->registrarLog($request, 'USUARIO_CREADO', [
                'target_type'  => $tipo,
                'target_id'    => (string) $user->id,
                'tipo_usuario' => $tipo,
                'ci'           => $user->ci,
                'ci_extension' => $user->ci_extension ?? null,
                'email'        => $user->email ?? null,
            ]);
        } catch (\Throwable $e) {
            Log::warning('No se pudo registrar log de auditoría al crear usuario: ' . $e->getMessage());
        }

        return response()->json([
            'message' => 'Usuario creado exitosamente.',
            'user'    => $this->formatearUsuario($user, $tipo),
        ], 201);
    }

    public function show(string $id): JsonResponse
    {
        $res = $this->buscarPorId($id);

        if (!$res || $res['tipo'] === 'admin') {
            return response()->json(['message' => 'Usuario no encontrado.'], 404);
        }

        return response()->json($this->formatearUsuario($res['user'], $res['tipo']));
    }

    public function update(UpdateUserRequest $request, string $id): JsonResponse
    {
        $res = $this->buscarPorId($id);

        if (!$res || $res['tipo'] === 'admin') {
            return response()->json(['message' => 'Usuario no encontrado.'], 404);
        }

        $user = $res['user'];
        $tipoActual = $res['tipo'];
        $data = $request->validated();

        unset($data['tipo_usuario']);

        if (empty($data['password'])) {
            unset($data['password']);
        }

        if ($tipoActual === 'admin') {
            unset($data['email']);
        }

        $camposAfectados = array_keys($data);
        $valoresAnteriores = [];

        foreach ($camposAfectados as $campo) {
            if ($campo === 'activo') {
                $valoresAnteriores[$campo] = filter_var($user->activo, FILTER_VALIDATE_BOOLEAN);
            } else {
                $valoresAnteriores[$campo] = $user->{$campo};
            }
        }

        if (isset($data['activo'])) {
            $esActivo = filter_var($data['activo'], FILTER_VALIDATE_BOOLEAN);
            $data['activo'] = $esActivo ? DB::raw('true') : DB::raw('false');
        }

        $user->update($data);

        if ($tipoActual === 'docente' && $request->has('materias_ids') && is_array($request->input('materias_ids'))) {
            $user->materias()->sync($request->input('materias_ids'));
        }

        try {
            $this->registrarLog($request, 'USUARIO_ACTUALIZADO', [
                'target_type'         => $tipoActual,
                'target_id'           => (string) $user->id,
                'tipo_usuario'        => $tipoActual,
                'campos_actualizados' => $camposAfectados,
                'valores_anteriores'  => $valoresAnteriores,
                'valores_nuevos'      => array_merge($data, [
                    'activo' => isset($data['activo']) ? filter_var($request->input('activo'), FILTER_VALIDATE_BOOLEAN) : $user->activo
                ]),
            ]);
        } catch (\Throwable $e) {
            Log::warning('No se pudo registrar log de auditoría al actualizar usuario: ' . $e->getMessage());
        }

        return response()->json([
            'message' => 'Usuario actualizado exitosamente.',
            'user'    => $this->formatearUsuario($user, $tipoActual),
        ]);
    }

    public function destroy(Request $request, string $id): JsonResponse
    {
        $res = $this->buscarPorId($id);

        if (!$res || $res['tipo'] === 'admin') {
            return response()->json(['message' => 'Usuario no encontrado.'], 404);
        }

        $user = $res['user'];
        $tipo = $res['tipo'];

        if ($error = $this->validarDesactivacion($request, $user, $tipo)) {
            return $error;
        }

        $estadoPrevio = filter_var($user->activo, FILTER_VALIDATE_BOOLEAN);

        $user->newQuery()->where('id', $user->id)->update(['activo' => DB::raw('false')]);

        // Desactivación en cascada: si es auxiliar, dar de baja sus asignaciones activas en exámenes pendientes
        if ($tipo === 'auxiliar') {
            $ahora = Carbon::now('America/La_Paz');
            $examenesPendientesIds = Examen::whereIn('estado', ['Programado', 'En proceso'])
                ->where(function ($q) use ($ahora) {
                    $q->where('fecha', '>', $ahora->toDateString())
                      ->orWhere(function ($sub) use ($ahora) {
                          $sub->where('fecha', $ahora->toDateString())
                              ->where('hora_fin', '>=', $ahora->toTimeString());
                      });
                })
                ->pluck('id');

            if ($examenesPendientesIds->isNotEmpty()) {
                DB::table('examen_auxiliar')
                    ->where('id_auxiliar', $user->id)
                    ->whereIn('id_examen', $examenesPendientesIds)
                    ->where('estado', 'Activo')
                    ->update([
                        'estado'     => 'Inactivo',
                        'updated_at' => $ahora,
                    ]);
            }
        }

        try {
            $this->registrarLog($request, 'USUARIO_DESACTIVADO', [
                'target_type'        => $tipo,
                'target_id'          => (string) $user->id,
                'tipo_usuario'       => $tipo,
                'valores_anteriores' => ['activo' => $estadoPrevio],
                'valores_nuevos'     => ['activo' => false],
                'motivo'             => 'Baja lógica desde módulo de usuarios',
            ]);
        } catch (\Throwable $e) {
            Log::warning('No se pudo registrar log de auditoría al desactivar usuario: ' . $e->getMessage());
        }

        return response()->json(['message' => 'Usuario desactivado exitosamente.']);
    }

    private function registrarLog(Request $request, string $accion, ?array $detalles = null): void
    {
        $actor = $request->user();

        $nombreCompleto = null;
        if ($actor) {
            $partes = array_filter([
                $actor->nombre ?? null,
                $actor->apellido_paterno ?? null,
                $actor->apellido_materno ?? null,
            ]);
            $nombreCompleto = !empty($partes) ? implode(' ', $partes) : null;
        }

        $rol = $actor ? strtolower(class_basename($actor)) : 'sistema';
        $emailOIdentificador = $actor?->email ?? ($actor ? $actor->ci : null);

        LogAuditoria::create([
            'user_type'         => $actor ? get_class($actor) : null,
            'user_id'           => $actor?->id,
            'rol_en_el_momento' => $rol,
            'usuario_nombre'    => $nombreCompleto,
            'usuario_email'     => $emailOIdentificador,
            'modulo'            => 'Usuarios',
            'accion'            => $accion,
            'ip_origen'         => $request->ip(),
            'user_agent'        => $request->userAgent(),
            'detalles'          => $detalles,
        ]);
    }

    private function obtenerClaseModelo(string $tipo): string
    {
        return match ($tipo) {
            'docente'  => Docente::class,
            'auxiliar' => Auxiliar::class,
            default    => Admin::class,
        };
    }

    private function buscarPorId(string $id): ?array
    {
        $mapaModelos = [
            'admin'    => Admin::class,
            'docente'  => Docente::class,
            'auxiliar' => Auxiliar::class,
        ];

        foreach ($mapaModelos as $tipo => $modelo) {
            $user = $modelo::find($id);
            if ($user) {
                return ['user' => $user, 'tipo' => $tipo];
            }
        }

        return null;
    }

    private function formatearUsuario(Model $u, string $tipo): array
    {
        $res = [
            'id'               => $u->id,
            'ci'               => $u->ci,
            'ci_extension'     => $u->ci_extension,
            'nombre'           => $u->nombre,
            'apellido_paterno' => $u->apellido_paterno,
            'apellido_materno' => $u->apellido_materno,
            'email'            => $u->email ?? null,
            'activo'           => filter_var($u->activo, FILTER_VALIDATE_BOOLEAN),
            'tipo_usuario'     => $tipo,
            'ultimo_acceso'    => $u->ultimo_acceso,
            'created_at'       => $u->created_at,
            'updated_at'       => $u->updated_at,
        ];

        if ($tipo === 'docente') {
            $res['materias'] = $u->relationLoaded('materias')
                ? $u->materias->map(fn ($m) => ['id' => $m->id, 'nombre' => $m->nombre])->values()
                : $u->materias()->select('materias.id', 'materias.nombre')->get();
        }

        return $res;
    }

    public function getMisMateriasDocente(Request $request): JsonResponse
    {
        $docente = $request->user();
        if (!$docente instanceof Docente) {
            return response()->json(['message' => 'Solo disponible para docentes.'], 403);
        }

        return $this->getMateriasDocente($docente->id);
    }

    public function syncMisMateriasDocente(Request $request): JsonResponse
    {
        $docente = $request->user();
        if (!$docente instanceof Docente) {
            return response()->json(['message' => 'Solo disponible para docentes.'], 403);
        }

        $request->validate([
            'materias_ids'   => ['present', 'array'],
            'materias_ids.*' => ['uuid', 'exists:materias,id'],
        ]);

        return $this->syncMateriasDocente($request, $docente->id);
    }

    public function getMateriasDocente(string $id): JsonResponse
    {
        $docente = Docente::with('materias:id,nombre')->find($id);
        if (!$docente) {
            return response()->json(['message' => 'Docente no encontrado.'], 404);
        }

        $todasMaterias = \App\Models\Materia::orderBy('nombre', 'asc')
            ->get(['id', 'nombre']);

        $asignadasIds = $docente->materias->pluck('id')->toArray();

        $materias = $todasMaterias->map(function ($m) use ($asignadasIds) {
            return [
                'id'       => $m->id,
                'nombre'   => $m->nombre,
                'asignada' => in_array($m->id, $asignadasIds),
            ];
        });

        return response()->json([
            'docente'   => [
                'id'     => $docente->id,
                'nombre' => trim("{$docente->nombre} {$docente->apellido_paterno} {$docente->apellido_materno}"),
                'email'  => $docente->email,
            ],
            'materias'  => $materias,
            'asignadas' => $docente->materias,
        ]);
    }

    public function syncMateriasDocente(Request $request, string $id): JsonResponse
    {
        $docente = Docente::find($id);
        if (!$docente) {
            return response()->json(['message' => 'Docente no encontrado.'], 404);
        }

        $materiasIds = $request->input('materias_ids', []);
        $docente->materias()->sync($materiasIds);

        try {
            $this->registrarLog($request, 'DOCENTE_MATERIAS_SINCRONIZADAS', [
                'target_type'  => 'docente',
                'target_id'    => $docente->id,
                'docente_id'   => $docente->id,
                'materias_ids' => $materiasIds,
            ]);
        } catch (\Throwable $e) {
            Log::warning('Error en log auditoria materias: ' . $e->getMessage());
        }

        return response()->json([
            'message'  => 'Materias del docente actualizadas exitosamente.',
            'materias' => $docente->materias()->get(['materias.id', 'materias.nombre']),
        ]);
    }

    public function vincularMateriaDocente(Request $request, string $id, string $idMateria): JsonResponse
    {
        $docente = Docente::find($id);
        if (!$docente) {
            return response()->json(['message' => 'Docente no encontrado.'], 404);
        }

        $materia = \App\Models\Materia::find($idMateria);
        if (!$materia) {
            return response()->json(['message' => 'Materia no encontrada.'], 404);
        }

        $docente->materias()->syncWithoutDetaching([$idMateria]);

        try {
            $this->registrarLog($request, 'DOCENTE_MATERIA_VINCULADA', [
                'target_type' => 'docente',
                'target_id'   => $docente->id,
                'id_materia'  => $idMateria,
                'materia'     => $materia->nombre,
            ]);
        } catch (\Throwable $e) {
            Log::warning('Error en log auditoria: ' . $e->getMessage());
        }

        return response()->json([
            'message'  => "Materia '{$materia->nombre}' vinculada al docente exitosamente.",
            'materias' => $docente->materias()->get(['materias.id', 'materias.nombre']),
        ]);
    }

    public function desvincularMateriaDocente(Request $request, string $id, string $idMateria): JsonResponse
    {
        $docente = Docente::find($id);
        if (!$docente) {
            return response()->json(['message' => 'Docente no encontrado.'], 404);
        }

        $materia = \App\Models\Materia::find($idMateria);

        $docente->materias()->detach($idMateria);

        try {
            $this->registrarLog($request, 'DOCENTE_MATERIA_DESVINCULADA', [
                'target_type' => 'docente',
                'target_id'   => $docente->id,
                'id_materia'  => $idMateria,
                'materia'     => $materia?->nombre,
            ]);
        } catch (\Throwable $e) {
            Log::warning('Error en log auditoria: ' . $e->getMessage());
        }

        return response()->json([
            'message'  => 'Materia desvinculada del docente exitosamente.',
            'materias' => $docente->materias()->get(['materias.id', 'materias.nombre']),
        ]);
    }

    private function aplicarFiltros($query, ?string $search, ?bool $activo, bool $tieneEmail): void
    {
        if ($search) {
            $query->where(function ($q) use ($search, $tieneEmail) {
                $q->where('nombre', 'ilike', "%{$search}%")
                  ->orWhere('apellido_paterno', 'ilike', "%{$search}%")
                  ->orWhere('apellido_materno', 'ilike', "%{$search}%")
                  ->orWhere('ci', 'ilike', "%{$search}%");

                if ($tieneEmail) {
                    $q->orWhere('email', 'ilike', "%{$search}%");
                }
            });
        }

        if ($activo !== null) {
            $query->whereRaw('activo is ' . ($activo ? 'true' : 'false'));
        }
    }

    private function validarDesactivacion(Request $request, Model $user, string $tipo): ?JsonResponse
    {
        if ($user->id === $request->user()->id) {
            return response()->json(['message' => 'No puedes desactivar tu propia cuenta.'], 400);
        }

        if ($tipo === 'admin' && filter_var($user->activo, FILTER_VALIDATE_BOOLEAN)) {
            $adminsActivos = Admin::whereRaw('activo is true')->count();
            if ($adminsActivos <= 1) {
                return response()->json([
                    'message' => 'No se puede desactivar al único administrador activo.'
                ], 422);
            }
        }

        if ($tipo === 'docente' && filter_var($user->activo, FILTER_VALIDATE_BOOLEAN)) {
            $ahora = Carbon::now('America/La_Paz');
            $tieneExamenesPendientes = Examen::where('id_docente', $user->id)
                ->whereIn('estado', ['Programado', 'En proceso'])
                ->where(function ($q) use ($ahora) {
                    $q->where('fecha', '>', $ahora->toDateString())
                      ->orWhere(function ($sub) use ($ahora) {
                          $sub->where('fecha', $ahora->toDateString())
                              ->where('hora_fin', '>=', $ahora->toTimeString());
                      });
                })
                ->exists();

            if ($tieneExamenesPendientes) {
                return response()->json([
                    'message' => 'No se puede desactivar al docente porque tiene exámenes programados pendientes o en curso.',
                ], 422);
            }
        }

        return null;
    }
}
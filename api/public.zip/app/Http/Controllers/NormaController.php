<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreNormaRequest;
use App\Http\Requests\SyncNormasExamenRequest;
use App\Http\Requests\UpdateNormaRequest;
use App\Models\Admin;
use App\Models\Auxiliar;
use App\Models\Docente;
use App\Models\Examen;
use App\Models\LogAuditoria;
use App\Models\Norma;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Cache;

class NormaController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $tipo = $request->query('tipo');
        $search = $request->query('search');

        if ($request->boolean('all') && $tipo === 'General' && !$search) {
            $normas = Cache::remember('catalogo_normas_generales', 600, function () {
                return Norma::where('tipo', 'General')->orderBy('titulo', 'asc')->get();
            });
            return response()->json($normas);
        }

        $query = Norma::query();
        if ($tipo) {
            $query->where('tipo', ucfirst(strtolower($tipo)));
        }
        if ($estado = $request->query('estado')) {
            $query->where('estado', ucfirst(strtolower($estado)));
        }
        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('titulo', 'ilike', "%{$search}%")
                  ->orWhere('descripcion', 'ilike', "%{$search}%");
            });
        }
        if ($request->boolean('all')) {
            return response()->json($query->orderBy('titulo', 'asc')->get());
        }

        return response()->json($query->orderBy('created_at', 'desc')->paginate(10));
    }

    public function store(StoreNormaRequest $request): JsonResponse
    {
        $data = $request->validated();
        $norma = Norma::create($data);

        $this->registrarAuditoria($request, 'NORMA_CREADA', [
            'target_type' => 'normas',
            'target_id'   => $norma->id,
            'titulo'      => $norma->titulo,
            'tipo'        => $norma->tipo,
        ]);

        return response()->json([
            'message' => 'Norma creada exitosamente.',
            'norma'   => $norma,
        ], 201);
    }

    public function show(string $id): JsonResponse
    {
        $norma = Norma::find($id);

        if (!$norma) {
            return response()->json(['message' => 'Norma no encontrada.'], 404);
        }

        return response()->json($norma);
    }

    public function update(UpdateNormaRequest $request, string $id): JsonResponse
    {
        $norma = Norma::find($id);

        if (!$norma) {
            return response()->json(['message' => 'Norma no encontrada.'], 404);
        }

        $esAdmin = $request->user() instanceof Admin;
        if ($norma->tipo === 'General' && !$esAdmin) {
            return response()->json([
                'message' => 'No tienes permisos para modificar normas de tipo General.',
            ], 403);
        }

        $data = $request->validated();
        if (isset($data['tipo']) && $data['tipo'] !== $norma->tipo) {
            throw ValidationException::withMessages(['tipo' => 'El tipo de una norma existente no puede cambiarse.']);
        }

        // Si se intenta desactivar la norma, verificar que no tenga exámenes pendientes o en curso
        if (isset($data['estado']) && $data['estado'] === 'Inactivo' && $norma->estado !== 'Inactivo') {
            $ahora = Carbon::now('America/La_Paz');
            $tieneExamenesPendientes = Examen::whereHas('normas', function ($q) use ($norma) {
                    $q->where('normas.id', $norma->id);
                })
                ->whereIn('estado', ['Programado', 'En proceso'])
                ->where(function ($q) use ($ahora) {
                    $q->where('fecha', '>', $ahora->toDateString())
                      ->orWhere(function ($sub) use ($ahora) {
                          $sub->where('fecha', $ahora->toDateString())
                              ->where('hora_fin', '>=', $ahora->toTimeString());
                      });
                })
                ->exists();

            if ($tieneExamenesPendientes) {
                return response()->json([
                    'message' => 'No se puede desactivar la norma porque está asociada a exámenes programados pendientes o en curso.',
                ], 422);
            }
        }

        $camposAfectados = array_keys($data);
        $valoresAnteriores = $norma->only($camposAfectados);

        $norma->update($data);

        $this->registrarAuditoria($request, 'NORMA_ACTUALIZADA', [
            'target_type'         => 'normas',
            'target_id'           => $norma->id,
            'campos_actualizados' => $camposAfectados,
            'valores_anteriores'  => $valoresAnteriores,
            'valores_nuevos'      => $data,
        ]);

        return response()->json([
            'message' => 'Norma actualizada exitosamente.',
            'norma'   => $norma,
        ]);
    }

    public function destroy(Request $request, string $id): JsonResponse
    {
        $norma = Norma::find($id);

        if (!$norma) {
            return response()->json(['message' => 'Norma no encontrada.'], 404);
        }

        $esAdmin = $request->user() instanceof Admin;
        if ($norma->tipo === 'General' && !$esAdmin) {
            return response()->json([
                'message' => 'No tienes permisos para eliminar normas de tipo General.',
            ], 403);
        }

        $ahora = Carbon::now('America/La_Paz');
        $tieneExamenesPendientes = Examen::whereHas('normas', function ($q) use ($norma) {
                $q->where('normas.id', $norma->id);
            })
            ->whereIn('estado', ['Programado', 'En proceso'])
            ->where(function ($q) use ($ahora) {
                $q->where('fecha', '>', $ahora->toDateString())
                  ->orWhere(function ($sub) use ($ahora) {
                      $sub->where('fecha', $ahora->toDateString())
                          ->where('hora_fin', '>=', $ahora->toTimeString());
                  });
            })
            ->exists();

        if ($tieneExamenesPendientes) {
            return response()->json([
                'message' => 'No se puede desactivar la norma porque está asociada a exámenes programados pendientes o en curso.',
            ], 422);
        }

        $detalles = [
            'target_type'        => 'normas',
            'target_id'          => $norma->id,
            'titulo'             => $norma->titulo,
            'tipo'               => $norma->tipo,
            'valores_anteriores' => ['estado' => $norma->estado],
            'valores_nuevos'     => ['estado' => 'Inactivo'],
        ];

        // Borrado lógico: pasar a Inactivo
        $norma->update(['estado' => 'Inactivo']);
        Cache::forget('catalogo_normas_generales');

        $this->registrarAuditoria($request, 'NORMA_DESACTIVADA', $detalles);

        return response()->json(['message' => 'Norma desactivada exitosamente.']);
    }

    /**
     * Reactivar una norma inactiva.
     */
    public function reactivar(Request $request, string $id): JsonResponse
    {
        $norma = Norma::find($id);

        if (!$norma) {
            return response()->json(['message' => 'Norma no encontrada.'], 404);
        }

        $norma->update(['estado' => 'Activo']);
        Cache::forget('catalogo_normas_generales');

        $this->registrarAuditoria($request, 'NORMA_REACTIVADA', [
            'target_type' => 'normas',
            'target_id'   => $norma->id,
            'titulo'      => $norma->titulo,
        ]);

        return response()->json([
            'message' => 'Norma reactivada exitosamente.',
            'norma'   => $norma,
        ]);
    }

    /**
     * Eliminación permanente física de una norma (únicamente si no tiene historial en examen_norma).
     */
    public function forceDelete(Request $request, string $id): JsonResponse
    {
        $norma = Norma::find($id);

        if (!$norma) {
            return response()->json(['message' => 'Norma no encontrada.'], 404);
        }

        $tieneHistorial = DB::table('examen_norma')->where('id_norma', $norma->id)->exists();
        if ($tieneHistorial) {
            return response()->json([
                'message' => 'No se puede eliminar permanentemente la norma porque cuenta con historial en evaluaciones asociadas. Solo puede mantenerse desactivada.',
            ], 422);
        }

        $detalles = [
            'target_type' => 'normas',
            'target_id'   => $norma->id,
            'titulo'      => $norma->titulo,
            'tipo'        => $norma->tipo,
        ];

        $norma->delete();
        Cache::forget('catalogo_normas_generales');

        $this->registrarAuditoria($request, 'NORMA_ELIMINADA_DEFINITIVAMENTE', $detalles);

        return response()->json(['message' => 'Norma eliminada permanentemente del sistema.']);
    }

    public function crearParticularesParaExamen(Request $request, string $id): JsonResponse
    {
        $examen = Examen::find($id);
        if (!$examen) {
            return response()->json(['message' => 'Examen no encontrado.'], 404);
        }

        if ($request->user() instanceof Docente && $examen->id_docente !== $request->user()->id) {
            return response()->json(['message' => 'Este examen pertenece a otro docente.'], 403);
        }

        $data = $request->validate([
            'particulares'               => ['required', 'array', 'min:1', 'max:20'],
            'particulares.*.titulo'      => ['required', 'string', 'max:150'],
            'particulares.*.descripcion' => ['required', 'string'],
        ]);

        $normas = DB::transaction(function () use ($examen, $data) {
            $creadas = collect();
            foreach ($data['particulares'] as $particular) {
                $existente = $examen->normas()
                    ->where('tipo', 'Particular')
                    ->where('titulo', trim($particular['titulo']))
                    ->where('descripcion', trim($particular['descripcion']))
                    ->first();
                if ($existente) {
                    $creadas->push($existente);
                    continue;
                }
                $norma = Norma::create([
                    'titulo'      => trim($particular['titulo']),
                    'descripcion' => trim($particular['descripcion']),
                    'tipo'        => 'Particular',
                ]);
                $examen->normas()->attach($norma->id);
                $creadas->push($norma);
            }
            return $creadas;
        });

        $this->registrarAuditoria($request, 'NORMAS_PARTICULARES_CREADAS_EXAMEN', [
            'target_type' => 'examen_norma',
            'target_id'   => $examen->id,
            'examen_id'   => $examen->id,
            'normas_ids'  => $normas->pluck('id')->all(),
        ]);

        return response()->json([
            'message' => 'Normas particulares vinculadas al examen.',
            'normas'  => $normas,
        ], 201);
    }

    public function syncExamenNormas(SyncNormasExamenRequest $request, string $idExamen): JsonResponse
    {
        $examen = Examen::find($idExamen);

        if (!$examen) {
            return response()->json(['message' => 'Examen no encontrado.'], 404);
        }

        if ($request->user() instanceof Docente && $examen->id_docente !== $request->user()->id) {
            return response()->json(['message' => 'Este examen pertenece a otro docente.'], 403);
        }

        $ids = array_values(array_unique($request->validated('normas')));
        $permitidas = Norma::whereIn('id', $ids)
            ->where(function ($query) use ($examen) {
                $query->where('tipo', 'General')
                    ->orWhereHas('examenes', fn ($q) => $q->where('examenes.id', $examen->id));
            })->count();
        if ($permitidas !== count($ids)) {
            throw ValidationException::withMessages([
                'normas' => 'Solo pueden asignarse normas generales o particulares de este examen.',
            ]);
        }

        $normasPrevias = $examen->normas()->pluck('normas.id')->toArray();

        $examen->normas()->sync($ids);

        $this->registrarAuditoria($request, 'NORMAS_ASIGNADAS_EXAMEN', [
            'target_type'        => 'examen_norma',
            'target_id'          => $examen->id,
            'examen_id'          => $examen->id,
            'valores_anteriores' => ['normas' => $normasPrevias],
            'valores_nuevos'     => ['normas' => $ids],
        ]);

        return response()->json([
            'message' => 'Normas asignadas al examen correctamente.',
            'normas'  => $examen->normas()->get(),
        ]);
    }

    private function registrarAuditoria(Request $request, string $accion, array $detalles = []): void
    {
        $user = $request->user();

        $rol = match ($user ? get_class($user) : null) {
            Admin::class    => 'admin',
            Docente::class  => 'docente',
            Auxiliar::class => 'auxiliar',
            default         => 'desconocido',
        };

        $nombreCompleto = $user ? trim("{$user->nombre} {$user->apellido_paterno} {$user->apellido_materno}") : 'Sistema';

        LogAuditoria::create([
            'user_type'         => $user ? get_class($user) : null,
            'user_id'           => $user?->id,
            'rol_en_el_momento' => $rol,
            'usuario_nombre'    => $nombreCompleto !== '' ? $nombreCompleto : ($user?->nombre ?? 'Sistema'),
            'usuario_email'     => $user?->email ?? null,
            'modulo'            => 'NORMAS',
            'accion'            => $accion,
            'ip_origen'         => $request->ip() ?? '127.0.0.1',
            'user_agent'        => $request->userAgent(),
            'detalles'          => $detalles,
        ]);
    }
}